import { atom } from "jotai";

const curBoardAtom = atom(null);

export default curBoardAtom;