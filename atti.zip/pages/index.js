// import Head from 'next/head'
// import Image from 'next/image'
import Main from '../components/Layout/Main'
// import styles from '../styles/Home.module.css'
import 'semantic-ui-css/semantic.min.css'

export default function Home() {
  return (
    <>
      {/* 여기 말고 app.js에 내비바 넣어주면 페이지가 바껴도 계속 보인다. */}
      {/* 주석은 ctrl+/ */}

      <Main />
      {/* 메인 부분 */}

      
    </>
  )
}