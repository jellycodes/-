/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/index";
exports.ids = ["pages/index"];
exports.modules = {

/***/ "./components/Layout/Main.jsx":
/*!************************************!*\
  !*** ./components/Layout/Main.jsx ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nconst Main = ()=>{\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n            className: \"bg-[url('/images/10.jpg')] bg-cover opacity-80\",\n            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                className: \"flex justify-center items-center min-h-screen text-xl font-extrabold ...\",\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"span\", {\n                    className: \"text-center text-transparent opacity-100 bg-clip-text bg-text-center bg-gradient-to-r from-pink-200 to-gray-200\",\n                    children: [\n                        \"오늘 하루 어땠나요?\",\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"br\", {}, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\playdata\\\\Desktop\\\\MidProject_Board\\\\midproject_board\\\\atti\\\\components\\\\Layout\\\\Main.jsx\",\n                            lineNumber: 9,\n                            columnNumber: 26\n                        }, undefined),\n                        \"털어놓기 힘든 고민 때문에 힘겨웠나요?\",\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"br\", {}, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\playdata\\\\Desktop\\\\MidProject_Board\\\\midproject_board\\\\atti\\\\components\\\\Layout\\\\Main.jsx\",\n                            lineNumber: 9,\n                            columnNumber: 52\n                        }, undefined),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"br\", {}, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\playdata\\\\Desktop\\\\MidProject_Board\\\\midproject_board\\\\atti\\\\components\\\\Layout\\\\Main.jsx\",\n                            lineNumber: 9,\n                            columnNumber: 57\n                        }, undefined),\n                        \"그렇다면 당신의 고민을 글로 적어보세요.\",\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"br\", {}, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\playdata\\\\Desktop\\\\MidProject_Board\\\\midproject_board\\\\atti\\\\components\\\\Layout\\\\Main.jsx\",\n                            lineNumber: 9,\n                            columnNumber: 84\n                        }, undefined),\n                        \"혼자 애쓰지 않아도 괜찮아요.\",\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"br\", {}, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\playdata\\\\Desktop\\\\MidProject_Board\\\\midproject_board\\\\atti\\\\components\\\\Layout\\\\Main.jsx\",\n                            lineNumber: 9,\n                            columnNumber: 105\n                        }, undefined),\n                        \"들어줄게요 당신이 괜찮아질 때까지.\",\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"br\", {}, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\playdata\\\\Desktop\\\\MidProject_Board\\\\midproject_board\\\\atti\\\\components\\\\Layout\\\\Main.jsx\",\n                            lineNumber: 9,\n                            columnNumber: 129\n                        }, undefined),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"br\", {}, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\playdata\\\\Desktop\\\\MidProject_Board\\\\midproject_board\\\\atti\\\\components\\\\Layout\\\\Main.jsx\",\n                            lineNumber: 9,\n                            columnNumber: 134\n                        }, undefined),\n                        \"뜻밖의 위로가 기다리고 있을 지도 몰라요.\"\n                    ]\n                }, void 0, true, {\n                    fileName: \"C:\\\\Users\\\\playdata\\\\Desktop\\\\MidProject_Board\\\\midproject_board\\\\atti\\\\components\\\\Layout\\\\Main.jsx\",\n                    lineNumber: 8,\n                    columnNumber: 13\n                }, undefined)\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\playdata\\\\Desktop\\\\MidProject_Board\\\\midproject_board\\\\atti\\\\components\\\\Layout\\\\Main.jsx\",\n                lineNumber: 7,\n                columnNumber: 11\n            }, undefined)\n        }, void 0, false, {\n            fileName: \"C:\\\\Users\\\\playdata\\\\Desktop\\\\MidProject_Board\\\\midproject_board\\\\atti\\\\components\\\\Layout\\\\Main.jsx\",\n            lineNumber: 6,\n            columnNumber: 7\n        }, undefined)\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\playdata\\\\Desktop\\\\MidProject_Board\\\\midproject_board\\\\atti\\\\components\\\\Layout\\\\Main.jsx\",\n        lineNumber: 5,\n        columnNumber: 5\n    }, undefined);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Main);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL0xheW91dC9NYWluLmpzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBO0FBQXlCO0FBRXpCLE1BQU1DLE9BQU8sSUFBTTtJQUNqQixxQkFDRSw4REFBQ0M7a0JBQ0MsNEVBQUNBO1lBQUlDLFdBQVU7c0JBQ1gsNEVBQUNEO2dCQUFJQyxXQUFVOzBCQUNiLDRFQUFDQztvQkFBS0QsV0FBVTs7d0JBQWtIO3NDQUNySCw4REFBQ0U7Ozs7O3dCQUFJO3NDQUFxQiw4REFBQ0E7Ozs7O3NDQUFJLDhEQUFDQTs7Ozs7d0JBQUk7c0NBQXNCLDhEQUFDQTs7Ozs7d0JBQUk7c0NBQWdCLDhEQUFDQTs7Ozs7d0JBQUk7c0NBQW1CLDhEQUFDQTs7Ozs7c0NBQUksOERBQUNBOzs7Ozt3QkFBSTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQXdCMUk7QUFFQSxpRUFBZUosSUFBSUEsRUFBQSIsInNvdXJjZXMiOlsid2VicGFjazovL21pZHByb2plY3RfYm9hcmQvLi9jb21wb25lbnRzL0xheW91dC9NYWluLmpzeD9lZGQzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCdcclxuXHJcbmNvbnN0IE1haW4gPSAoKSA9PiB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctW3VybCgnL2ltYWdlcy8xMC5qcGcnKV0gYmctY292ZXIgb3BhY2l0eS04MFwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlciBtaW4taC1zY3JlZW4gdGV4dC14bCBmb250LWV4dHJhYm9sZCAuLi5cIj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgdGV4dC10cmFuc3BhcmVudCBvcGFjaXR5LTEwMCBiZy1jbGlwLXRleHQgYmctdGV4dC1jZW50ZXIgYmctZ3JhZGllbnQtdG8tciBmcm9tLXBpbmstMjAwIHRvLWdyYXktMjAwXCI+XHJcbiAgICAgICAgICAgICAg7Jik64qYIO2VmOujqCDslrTrlaDrgpjsmpQ/PGJyLz7thLjslrTrhpPquLAg7Z6Y65OgIOqzoOuvvCDrlYzrrLjsl5Ag7Z6Y6rKo7Jug64KY7JqUPzxici8+PGJyLz7qt7jroIfri6TrqbQg64u57Iug7J2YIOqzoOuvvOydhCDquIDroZwg7KCB7Ja067O07IS47JqULjxici8+7Zi87J6QIOyVoOyTsOyngCDslYrslYTrj4Qg6rSc7LCu7JWE7JqULjxici8+65Ok7Ja07KSE6rKM7JqUIOuLueyLoOydtCDqtJzssK7slYTsp4gg65WM6rmM7KeALjxici8+PGJyLz7rnLvrsJbsnZgg7JyE66Gc6rCAIOq4sOuLpOumrOqzoCDsnojsnYQg7KeA64+EIOuqsOudvOyalC5cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogPGRpdiBjbGFzcz1cImxnOnctZnVsbCB3LWZ1bGwgYmctYmx1ZS0wXCI+XHJcbiAgICAgICA8ZGl2IGNsYXNzPVwieHh4X2ltZ1dyYXAgZmxleCBmbGV4LWNvbCBteS1hdXRvIGl0ZW1zLWNlbnRlciBteC0zXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBoLXNjcmVlblwiPlxyXG4gICAgICAgICAgICAgPGRpdiBjbGFzcz1cIm0tYXV0b1wiPlxyXG4gICAgICAgICAgICAgICAgPGltZyBzcmM9XCIvaW1hZ2VzLzEuanBnXCIgd2lkdGg9XCIxNDBcIj5cclxuICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICA8L2Rpdj5cclxuICAgICAgIDwvZGl2PiAqL31cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHsvKiDrrLjqtawg6re46528642w7J207IWYICovfVxyXG4gICAgICAgey8qIDxkaXYgY2xhc3M9XCJiZy1ncmFkaWVudC10by1yIGZyb20tcHVycGxlLTkwMCB0by1waW5rLTkwMFwiPiAqL31cclxuICAgICAgIHsvKiA8ZGl2IGNsYXNzTmFtZT1cImJnLWZpeGVkIGJnLXBpbmstMzAwIGJnLWNlbnRlciBiZy1yZXBlYXQgYmctY292ZXJcIlxyXG4gICAgICAvLyBzdHlsZT17e2JhY2tncm91bmRJbWFnZTogdXJsKC4vaW1hZ2VzLzEuanBnKX19XCI+XHJcbiAgICAgIC8vICAgc3R5bGU9e3ttYXJnaW5SaWdodDogc3BhY2luZyArICdlbSd9fVxyXG4gICAgICAvLyA8L2Rpdj4gKi99XHJcblxyXG4gICAgIDwvZGl2PlxyXG4gIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgTWFpbiJdLCJuYW1lcyI6WyJSZWFjdCIsIk1haW4iLCJkaXYiLCJjbGFzc05hbWUiLCJzcGFuIiwiYnIiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./components/Layout/Main.jsx\n");

/***/ }),

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Home)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _components_Layout_Main__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../components/Layout/Main */ \"./components/Layout/Main.jsx\");\n/* harmony import */ var semantic_ui_css_semantic_min_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! semantic-ui-css/semantic.min.css */ \"./node_modules/semantic-ui-css/semantic.min.css\");\n/* harmony import */ var semantic_ui_css_semantic_min_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(semantic_ui_css_semantic_min_css__WEBPACK_IMPORTED_MODULE_2__);\n// import Head from 'next/head'\n// import Image from 'next/image'\n\n\n// import styles from '../styles/Home.module.css'\n\nfunction Home() {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_Layout_Main__WEBPACK_IMPORTED_MODULE_1__[\"default\"], {}, void 0, false, {\n            fileName: \"C:\\\\Users\\\\playdata\\\\Desktop\\\\MidProject_Board\\\\midproject_board\\\\atti\\\\pages\\\\index.js\",\n            lineNumber: 13,\n            columnNumber: 7\n        }, this)\n    }, void 0, false);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9pbmRleC5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBQSwrQkFBK0I7QUFDL0IsaUNBQWlDO0FBQ2pDO0FBQTRDO0FBQzVDLGlEQUFpRDtBQUNSO0FBRTFCLFNBQVNDLE9BQU87SUFDN0IscUJBQ0U7a0JBSUUsNEVBQUNELCtEQUFJQTs7Ozs7O0FBTVgsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL21pZHByb2plY3RfYm9hcmQvLi9wYWdlcy9pbmRleC5qcz9iZWU3Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIGltcG9ydCBIZWFkIGZyb20gJ25leHQvaGVhZCdcclxuLy8gaW1wb3J0IEltYWdlIGZyb20gJ25leHQvaW1hZ2UnXHJcbmltcG9ydCBNYWluIGZyb20gJy4uL2NvbXBvbmVudHMvTGF5b3V0L01haW4nXHJcbi8vIGltcG9ydCBzdHlsZXMgZnJvbSAnLi4vc3R5bGVzL0hvbWUubW9kdWxlLmNzcydcclxuaW1wb3J0ICdzZW1hbnRpYy11aS1jc3Mvc2VtYW50aWMubWluLmNzcydcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEhvbWUoKSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIHsvKiDsl6zquLAg66eQ6rOgIGFwcC5qc+yXkCDrgrTruYTrsJQg64Sj7Ja07KO866m0IO2OmOydtOyngOqwgCDrsJTqu7Trj4Qg6rOE7IaNIOuztOyduOuLpC4gKi99XHJcbiAgICAgIHsvKiDso7zshJ3snYAgY3RybCsvICovfVxyXG5cclxuICAgICAgPE1haW4gLz5cclxuICAgICAgey8qIOuplOyduCDrtoDrtoQgKi99XHJcblxyXG4gICAgICBcclxuICAgIDwvPlxyXG4gIClcclxufSJdLCJuYW1lcyI6WyJNYWluIiwiSG9tZSJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/index.js\n");

/***/ }),

/***/ "./node_modules/semantic-ui-css/semantic.min.css":
/*!*******************************************************!*\
  !*** ./node_modules/semantic-ui-css/semantic.min.css ***!
  \*******************************************************/
/***/ (() => {



/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/index.js"));
module.exports = __webpack_exports__;

})();